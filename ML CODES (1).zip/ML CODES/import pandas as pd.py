#Import Required Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

#Load the Dataset
data = pd.read_csv("Wholesale customers data.csv")
print("Dataset Loaded Successfully")
data.head()

#Dataset Exploration
print("Shape of dataset:", data.shape)

#Check Feature Names
print("Feature Names:")
print(data.columns)

#Check Data Types
print(data.dtypes)

#Identify Data Issues
#Check Missing Values
print("Missing Values:")
print(data.isnull().sum())

#Check Duplicate Rows
print("Duplicate Rows:", data.duplicated().sum())

#If duplicates exist, remove them:
data = data.drop_duplicates()

#Detect Outliers (Visualization)
plt.figure(figsize=(10,6))
sns.boxplot(data=data)
plt.title("Boxplot to Detect Outliers")
plt.show()

#Feature Scaling
#Machine learning algorithms work better when features are scaled.
#We use Standardization.
scaler = StandardScaler()
scaled_data = scaler.fit_transform(data)
scaled_data = pd.DataFrame(scaled_data, columns=data.columns)
scaled_data.head()

#Apply K-Means Clustering
#We apply K-Means Clustering.
kmeans = KMeans(n_clusters=3, random_state=42)
clusters = kmeans.fit_predict(scaled_data)
data['Cluster'] = clusters

#View Cluster Results
print(data.head())

#Visualize Clusters
plt.figure(figsize=(8,6))
plt.scatter(data['Grocery'], data['Milk'], c=data['Cluster'], cmap='viridis')
plt.xlabel("Grocery Spending")
plt.ylabel("Milk Spending")
plt.title("Customer Clusters")
plt.show()

#Cluster Summary
cluster_summary = data.groupby('Cluster').mean()
print(cluster_summary)